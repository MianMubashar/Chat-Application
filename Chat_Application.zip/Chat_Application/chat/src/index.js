import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCRusj2lO3l1OlXNP7o4H02YCC1LDmofec",
  authDomain: "react-chat-app-607c6.firebaseapp.com",
  databaseURL: "https://react-chat-app-607c6-default-rtdb.firebaseio.com",
  projectId: "react-chat-app-607c6",
  storageBucket: "react-chat-app-607c6.appspot.com",
  messagingSenderId: "1030797793421",
  appId: "1:1030797793421:web:3548c971f4aa8fc767eac4",
  measurementId: "G-6DFGW00KMW"
};


const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

ReactDOM.render(
  <>
    <App />
  </>,
  document.getElementById('root')
)