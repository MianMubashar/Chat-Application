// import React, { useState } from 'react'
// import './App.css'
// const App = () => {
//   const [name, setname] = useState("Dummy User")
//   const [chats, setchats] = useState([]);
//   const [masg, setmasg] = useState('');
//   const sendchat = () => {
//     const c = [...chats];
//     c.push({ name, massage: masg })
//     setchats(c)
//     setmasg('')
//   }

//   return (
//     <>

//       <div>

//         {name ? null : <div>
//           <input type='text' placeholder='Enter the name' onBlur={(e) => setname(e.target.value)} >

//           </input>
//         </div>}
//         <div />
//         <h1>User: {name}</h1>
//         <div className='chat-container' >
//           {chats.map(c => <div className={`container ${c.name === name ? 'me' : ''}`} >

//             <p className='chatbox' >
//               <strong>{c.name} </strong>
//               <span>{c.message}</span>
//             </p>
//           </div>)}

//         </div>

//         <div className='btn' >

//           <input type='text' placeholder='Enter The massege' onInput={e => setmasg(e.target.value)} >
//             value{masg}
//           </input>
//           <button onClick={e => sendchat(e.target.value)} >Send</button>
//         </div>

//       </div>
//     </>
//   );
// }

// export default App

// // ========================chat GPT============================

// import React, { useEffect, useState } from 'react';
// import { getDatabase, push, ref, set, onChildAdded } from "firebase/database";
// import { GoogleAuthProvider , getAuth, signInWithPopup} from "firebase/auth"; // google-sign-in

// import './App.css';

// const App = () => {
// // -----Google-sign-in-----
// const provider = new GoogleAuthProvider();
// // const auth = getAuth();

// // -------------------

//   const [name, setName] = useState("Dummy User");
//   const [chats, setChats] = useState([
//     // { name: 'user1', message: 'message1' },
//     // { name: 'dummy', message: 'message2' },
//   ]);
//   const [msg, setMsg] = useState('');
//   const db = getDatabase();
//   const chatlistref = ref(db, 'chats')

//   useEffect(() => {

//     onChildAdded(chatlistref, (data) => {
//       setChats(chats => [...chats, data.val()])
//       setTimeout(() => {
//         udateheight()
//       }, 1000)
//     });
//   }, [])

//   const udateheight = () => {
//     const e = document.getElementById('chat')
//     if (e) {
//       e.scrollTo = e.scrollHeight;

//     }
//   }

//   // =========firebase==============
//   const sendChat = () => {

//     const chatref = push(chatlistref);
//     set(chatref, {
//       name: name, message: msg
//     });
//     // ==========================/

//     // const c = [...chats];
//     // c.push()
//     // setChats(c);
//     setMsg('');
//   };

//   return (
//     <>
//       <div>
//         <input
//           type='text'
//           placeholder='Enter the name'
//           onBlur={e => setName(e.target.value)}
//         />
//       </div>

//       {/* <button onClick={e=>{goooglelogin()}} >Google lig in</button> */}

//       <div>
//         <h1>User: {name}</h1>
//         <div id='chat' className='chat-container'>
//           {chats.map((c, index) => (
//             <div
//               key={index}
//               className={`container ${c.name === name ? 'me' : ''}`}
//             >
//               <p className='chatbox'>
//                 <strong>{c.name}</strong>
//                 <span>{c.message}</span>
//               </p>
//             </div>
//           ))}
//         </div>

//         <div className='btn'>
//           <input
//             type='text'
//             placeholder='Enter The message'
//             value={msg}
//             onChange={e => setMsg(e.target.value)}
//           />

//           <button onClick={sendChat}>Send</button>
//         </div>
//       </div>
//     </>
//   );
// };

// export default App;

// ======================


import React, { useEffect, useState } from 'react';
import { getDatabase, push, ref, set, onChildAdded } from "firebase/database";
import { GoogleAuthProvider, getAuth, signInWithPopup } from "firebase/auth";

import './App.css';

const App = () => {
  // Firebase Auth and Google Sign-In Setup
  const provider = new GoogleAuthProvider();
  const auth = getAuth();
  // -------------/

  const [name, setName] = useState("Dummy User");
  const [chats, setChats] = useState([]);
  const [msg, setMsg] = useState('');
  // ----------DB-------------
  const db = getDatabase();
  const chatlistRef = ref(db, 'chats');
  // -------------

  // --------Google-Sign-in----------

  const googleLogin = () => {
    signInWithPopup(auth, provider)
      .then((result) => {
        const user = result.user;
        setName({ name: user.displayName, email: user.email });  // username or Email b show ho gi
        console.log(user);
      }).catch((error) => {
        console.error("Error during Google Sign-In: ", error);
        alert("Failed to sign in. Please try again.");
      });
  };

  // ----------Google-Sign-in---------------------

  useEffect(() => {
    const unsubscribe = onChildAdded(chatlistRef, (data) => {
      setChats(chats => [...chats, data.val()]);
      setTimeout(updateHeight, 1000);
    });

    return () => unsubscribe();
  }, []);

  // ---------Scrol----------------
  const updateHeight = () => {
    const chatContainer = document.getElementById('chat');
    if (chatContainer) {
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }
  };
  // -----------------/
  // ----------DB--------------
  const sendChat = () => {
    const chatRef = push(chatlistRef);
    set(chatRef, {
      name: name.name, // Updated to reflect the refactored state
      message: msg
    });
    setMsg('');
  };
  // -----------------------
  return (
    <>
      {/* <div>
        <input
          type='text'
          placeholder='Enter your name'
          onChange={e => setName(e.target.value)}
          value={name.name} // Controlled input for user name
        />
      </div> */}

      <button onClick={googleLogin}>Google Sign In</button>

      <div>
        <h1>User: {name.name || "Anonymous"}</h1>
        <div id='chat' className='chat-container'>
          {chats.map((c, index) => (
            <div
              key={index}
              className={`container ${c.name === name.name ? 'me' : ''}`}
            >
              <p className='chatbox'>
                <strong>{c.name}</strong>
                <span>{c.message}</span>
              </p>
            </div>
          ))}
        </div>

        <div className='btn'>
          <input
            type='text'
            placeholder='Enter the message'
            value={msg}
            onChange={e => setMsg(e.target.value)}
          />
          <button onClick={sendChat}>Send</button>
        </div>
      </div>
    </>
  );
};

export default App;
